# Tounsi Trainer — Import-Methodik & Datenquellen

Wie neue Vokabeln aus einer konkreten Quelle (PDF, Foto, Web-Scraping) extrahiert und in die Zielkonvention übersetzt werden, plus die Detail-Historie jeder Rohdatenquelle. Die eigentlichen Imports (Uni-Wien, TUNICO, Derja Ninja, Peace Corps, Instagram) sind abgeschlossen — dieser Inhalt ist nur noch bei einem NEUEN Import oder einer neuen Quelle relevant, nicht für die laufende Vokabel-Prüfung (siehe `SKILL.md`). Für Cross-Source-Abgleich gegen die bereits importierten Daten: `SKILL.md` → vocab_lookup.

## PDF/Foto-Extraktion (Teil von SKILL.md → Der Prozess, Schritt 1, Eingang B)

**Vollständig extrahieren.** Bei PDFs/Fotos: Text (pdfplumber, inkl. `extract_tables()`) UND visuell (pdftoppm 150dpi, jede Seite mit `view` prüfen) — nie Seiten überspringen. Nicht nur die offizielle Wortschatztabelle: Dialoge, Grammatik-Beispielsätze, Übungssätze, Bildunterschriften enthalten oft zusätzliche Wörter/Sätze und müssen genauso vollständig geprüft werden. Ganze Sätze gehören ebenfalls als eigene Zeile in `vocabulary` (topic="Phrasen"/"Ausdrücke"), auch wenn die Einzelwörter schon vorhanden sind.

**Arbeitsweise pro Lektion:** Nils lädt alle Fotos einer Lektion in einer Nachricht hoch, Claude arbeitet intern häppchenweise pro Tabelle/Bereich ab (erst Verben, dann Wortschatz, dann Berufe, ...) und zeigt nach jedem Bereich das Ergebnis — sonst werden zuverlässig Wörter übersehen und bereits vorhandene Wörter versehentlich nochmal angelegt. Seitenzahl-Lücken explizit ansprechen und nachfragen, nie ein Wort als "fehlt bestimmt auf der fehlenden Seite" vermuten.

## Prüfprotokoll (Pflicht am Ende jeder Auswertung)

Am Ende jeder PDF-Auswertung immer eine Tabelle anhängen:

| Datei | Seiten | Methode |
|---|---|---|
| Dateiname.pdf | 1–N (alle) | pdfplumber (Text+Tabellen) + visuell einzeln |

Zusätzlich vermerken: Duplikatcheck (gegen welche Quellen, wie viele `project_knowledge_search`-Abfragen), offene Rückfragen (gesammelt, nicht einzeln während der Analyse). Zweck: Nutzer sieht auf einen Blick, ob alle Seiten vollständig geprüft wurden.

## Bulk-Insert bei großen Mengen

**Über ~1000 Zeilen NICHT per SQL-Text-Batches über `execute_sql` oder Subagenten** — kostet unverhältnismäßig viele Tokens (Text wird doppelt bezahlt: erst per `Read` in den Kontext, dann nochmal als `execute_sql`-Parameter) und Subagenten können durch Account-Session-Limits mitten im Batch abbrechen.

**Stattdessen: direkter POST an die PostgREST-Bulk-Insert-API, am Modellkontext vorbei.** Nils gibt einen `service_role`/`secret`-Key aus dem Supabase-Dashboard (Project Settings → API, Format `sb_secret_...`) durch. Kleines Python-Script schreiben, das die Daten (als JSON) in Chunks (~500 Zeilen) per `urllib`/`requests` als `POST https://<project-ref>.supabase.co/rest/v1/<tabelle>` mit Headern `apikey`/`Authorization: Bearer <key>`/`Prefer: return=minimal` verschickt. Key nur als Env-Var übergeben (`export SB_SECRET=... && python3 script.py`), landet nicht im Skript, Skript nach Gebrauch löschen. **Vor dem Insert: Zeilen-Reihenfolge gegen den bereits importierten Teilbestand prüfen** (`SELECT id, xml_id FROM tabelle ORDER BY id DESC LIMIT 1` gegen den lokalen JSON-Index abgleichen), um Duplikate/Lücken bei fortgesetzten Imports zu vermeiden.

Kleinere Mengen (< ~300 Zeilen): weiterhin direkt per `execute_sql` in 2-4 Batches.

## Datenquellen im Detail

Für jede Quelle gilt der Prozess aus `SKILL.md` (Schritt 1, Eingang B) unverändert — hier steht nur, was pro Quelle unterschiedlich ist: die Ausgangsnotation (→ Chat-Alphabet-Umwandlung) und quellenspezifische Tabellen/Mechanik. Kurzreferenz der Tabellen für laufende Cross-Source-Abfragen: `SKILL.md` → vocab_lookup.

### Uni-Wien-Lehrskripte (Tunesisch-Arabisch I & II)

Zwei Lehrskripte, 13 Lektionen insgesamt. Wissenschaftlich strukturiert: Dialoge, Wortschatz-Tabellen, Grammatik-Kapitel, Übungen, Ausspracheübungen. Eigene wissenschaftliche Transliteration (IPA-nah, Emphatika-/Langvokal-Markierung), kein arabisches Original. Enthält den Rohstoff für den Kurs-Modus (siehe COURSE_MODE.md).

**Umwandlungstabelle (Uni Wien → Chat-Alphabet):**

| Uni Wien | Chat-Alphabet | Beispiel |
|---|---|---|
| ʔ (Hamza) | meist weggelassen | — |
| ʕ | 3 | sabʕa → sab3a |
| ḥ | 7 | ḥāl → 7al |
| x / ḫ | kh | xamsa → khamsa |
| ġ | gh | ġalla → ghalla |
| q | q | qlam → qlam |
| š | sh | šbāb → shbab |
| ž | j | rāžil → rajel |
| y | y | yimši → yimshi |
| ā/ī/ū (Langvokale) | kein Sonderzeichen | ṣbāḥ → sba7 |
| ṣ/ṭ (Emphatika) | s/t | ṣbāḥ → sba7, ṭūl → toul |
| ḍ | dh (siehe Ziel-Konvention in SKILL.md) | ḍayyiq → dhayyaq |
| ḏ/ṯ/ẓ | th (siehe Ziel-Konvention in SKILL.md) | hāḏa → hetha |
| ḷ, ṃ, ṛ, ḅ | keine Unterscheidung | žāṛi → jari |

Diese Umwandlung gilt genauso für Fließtext in `grammar_notes`/`course_exercises`, nicht nur Einzelvokabeln — nach dem Schreiben gezielt nach übrig gebliebenen Uni-Wien-Sonderzeichen suchen (ā, š, ʕ, ḥ, ṛ, ṭ, ġ, ž).

**Pflicht-Gegencheck nach jeder Konvertierung: Konsonant für Konsonant gegen das arabic_script prüfen, nicht nur "sieht plausibel aus".** Falsch konvertierte Transliteration lässt auch den Duplikat-Check ins Leere laufen. Checkliste: arabic_script ح → darija muss "7" haben; خ → "kh"; ع → "3"; غ → "gh"; ش → "sh". Bei Widerspruch: darija korrigieren, nicht arabic_script. (Präzedenzfall, dreifacher Fehler in einem Batch: PRECEDENTS.md → Uni-Wien-Lehrskripte.)

**Fehlendes arabic_script: zuerst Derja Ninja, erst danach selbst erstellen.**
1. Deutsche Bedeutung ins Englische übersetzen, gegen `derja_ninja_entries` suchen (offline, dann live `script=english`)
2. Zusätzlich über die (ins Ninja-Schema konvertierte) Transliteration suchen (`script=transliterated`) — unabhängige zweite Spur
3. Treffer mit passender Bedeutung → dessen `arabic_script` übernehmen (inkl. Audio), NICHT selbst aus der Uni-Wien-Umschrift ableiten
4. Kein Treffer → direkt aus der Uni-Wien-Umschrift ableiten, Pflicht-Gegencheck bleibt nötig
5. Bei einem ganzen Lektions-Batch: Schritt 1+2 als eigener Sweep vor dem Einzel-Import, nicht Wort für Wort verschränkt
6. Ergebnis in `vocabulary.internal_note` festhalten (z.B. „Ninja-bestätigt (Bedeutungssuche)", „arabic_script selbst erstellt, kein Ninja-Treffer") — auch im Trainer-Editor sichtbar/editierbar (`ei-nt`)

Bei Duplikaten immer die exakte bestehende DB-Schreibweise übernehmen, nicht neu ableiten. Erst `project_knowledge_search`, dann ggf. anpassen.

**Duplikat-Check: "Fällig setzen" statt Ausschluss.** Ergänzt die Standard-Duplikat-Kriterien nur um eine andere Konsequenz: Wort bereits vorhanden → nicht ausschließen, `progress.next_review = now()` setzen (nur wenn `next_review IS NULL` oder keine progress-Zeile — bestehende Zeitpläne nie überschreiben). Wort neu → normale Neuanlage + sofort fällig. Grenzfall (Homonym/Synonym) → nicht automatisch einordnen, dem Nutzer als offene Frage vorlegen.

**Grammatik-Regeln rückwirkend auf Bestand anwenden:** nach jeder neuen Lektion prüfen, ob sich eine explizite Lautlehre-/Grammatikregel als Textmuster gegen den Bestand durchsuchen lässt (bevorzugt direkt per SQL, token-günstiger als `project_knowledge_search`). **Zwei Supabase-MCP-Fallen:** `CREATE TEMP TABLE` funktioniert nicht über mehrere `execute_sql`-Calls hinweg (jeder Call = eigene Connection) — alles in einer Query/CTE bündeln; bei mehreren SELECTs in einem Call kommt nur das letzte Ergebnis zurück — immer nur ein SELECT pro Call. Treffer klassifizieren (nur Transliteration / auch arabic_script betroffen / Dialektfrage ungeklärt → Semia/Ninja vorlegen), volle Liste zeigen, erst nach Bestätigung schreiben. Bei unscharfen Regeln (Possessivsuffixe, Verbkonjugationsmuster): Stichprobe statt Vollständigkeitsanspruch, explizit kennzeichnen.

### TUNICO

"A Digital Dictionary of Tunis Arabic" (Uni Wien, Dallaji/Gabsi/Procházka/Ritt-Benmimoun u.a., 2016) — direkt aus derselben akademischen Quelle wie unser Uni-Wien-Kursmaterial (1.056 von 7.543 Einträgen zitieren "Ritt-Benmimoun 2014", genau unsere Kursquelle). Live-Website hinter Anubis-Bot-Schutz — **nicht versuchen zu umgehen**, stattdessen Rohdaten auf GitHub (`acdh-oeaw/tunico-data`) klonen/parsen. Für Seiten außerhalb der öffentlichen Repos (z.B. Korpus-Statistikseiten): Nils um Copy-Paste bitten.

**Tabellen** (alle mit `*_orig`=wissenschaftliche DMG-Transliteration, `*_chatalpha`=automatisch umgewandelt, getrennte Spalten):
- `tunico_import` (7.543 Zeilen): `lemma_orig`/`_chatalpha`, `variants_*`, `pos`, `subc`, `root_*`, `inflected` (jsonb), `senses` (jsonb `{en,de,fr}`), `bibl`. Kein arabisches Original.
- `tunico_corpus_verbs`/`_adjectives`/`_nouns` (300/64/300 Zeilen): häufigste Wörter im Korpus mit `rank`/`frequency` und allen belegten Flexionsformen (`forms_*`, Array) — wertvoll für Priorisierung.
- `tunico_corpus_wordforms` (9.874 Zeilen): alle belegten Wortformen nach Häufigkeit, direkt aus den TEI-XML-Korpustexten (`xmlfiles/` im Repo) nachgerechnet, nicht per Copy-Paste — bei TUNICO-Statistikseiten immer erst prüfen, ob sich Zahlen aus den rohen `xmlfiles/` nachrechnen lassen.

**Umwandlung `*_orig` → `*_chatalpha`:** ʔ→weg, ʕ→3, ḥ→7, x/ḫ→kh, ġ→gh, š→sh, ž/ǧ→j, ḍ→dh, ḏ/ṯ/ẓ→th, ā/ī/ū/ē/ō→ohne Sonderzeichen, ṣ/ṭ→s/t, ḷ/ṃ/ṛ/ḅ/ṇ→ohne Unterscheidung, ᵊ→weg, französische Nasalvokale (ä/ǟ→e, õ/ȭ/ȫ→o, ü/ǖ→u). Vor jedem Bulk-Import auf einer neuen Teilmenge einmal `unicodedata.category(ch)=='Mn'` auf die `*_chatalpha`-Spalten prüfen, um freistehende combining marks zu erkennen (Präzedenzfall: PRECEDENTS.md → TUNICO).

**TUNICO-Kandidaten-Review im Trainer** (Tab "🗂️ TUNICO", `showTunicoCandidates()`): manuelles Abarbeiten der Frequenz-Lücken-Analyse in Batches, gefiltert nach Kategorie/Status. Tabelle `tunico_candidates` (664 Zeilen) speichert `auto_verdict`, `matched_vocab_id`, `status`, `vocabulary_id`, `comment`, `decided_at`. Drei Aktionen: 🔗 Verknüpfen (Suche gegen `ALL_VOCAB`, `progress`-Zeile mit `next_review=jetzt`), ➕ Neu anlegen (`flagged:true`, `arabic_script:null`), ⏭ Überspringen.

**TUNICOs Lemma ist immer die Grundform — für Plurale, Duale und Flexionsformen `inflected` benutzen.** Die Spalte trägt Einträge der Form `{ana, orig, chatalpha}` mit Analysetag (`#n_pl`, `#n_dual`, `#n_unit_dual`, `#v_pres_sg_p3`). Ohne sie zieht ein Skelettabgleich den Plural systematisch auf den Singular: `fnejin` „Tassen" auf `finjan` „Tasse", `mgharif` „Löffel (Pl.)" auf `mgharfa`, `amriken` „Amerikaner (Pl.)" auf `amrikani` „amerikanisch". Unser Bestand ist voll von Pluralen, das ist also kein Randfall. Ebenso: trägt die `darija` einen **Artikel** (`el-`, `esh-`, `ez-`), muss er vor der Suche abgetrennt und danach wieder vorangestellt werden — sonst zählt das Skelett ihn mit und trifft nie ein Lemma (`el-7imaya`, `esh-shahada`, `el-qahwa`).

**Verb-Zitierform ≠ Trainer-Konvention:** TUNICOs `lemma_chatalpha` ist die bloße Stammform, der Trainer nutzt die 3. Person Singular Präsens mit y-/t-Präfix — beim Verknüpfen/Neuanlegen die passende Flexionsform aus `tunico_corpus_verbs.forms_chatalpha` wählen (siehe `_tnGuessVerbForm()`), nie die reine Stammform übernehmen. Nomen/Adjektive sind davon nicht betroffen.

**Bei jeder TUNICO-Verknüpfung/Neuanlage: deutsches Gloss-Feld gegen `de_gloss` auf fehlende Bedeutungsfacetten prüfen.** `de_gloss` bei "/" in Einzel-Sinne zerlegen, gegen `german` abgleichen. Bei echter zusätzlicher Facette ohne Wortüberlappung: zuerst prüfen, ob dasselbe/ein sehr ähnliches Darija-Wort bereits einen EIGENEN Bestandseintrag für genau diese Bedeutung hat, bevor angehängt wird. Unverwandtes Homonym gleicher Schreibung ist kein Blocker, nur eine Randnotiz. Bei Verdacht auf andere Wurzel/unverwandte Bedeutung: als Homonym-Konflikt melden, echte Wurzel-Prüfung gegen `tunico_import` nötig statt automatisch zusammenzuführen.

Bei einem scheinbaren Bedeutungsfehler, der nur auf EINEM Ninja-Teiltreffer beruht: vor der Korrektur zusätzlich `tunico_import` nach demselben Lemma/derselben Wurzel durchsuchen — TUNICO listet oft das komplette Bedeutungsspektrum, eine einzelne Ninja-Trefferzeile nur eine Facette (Details: PRECEDENTS.md → TUNICO).

**Beim automatischen Verknüpfen bevorzugt auf Einzelwort-Einträge matchen, nicht auf irgendeinen Treffer mit passendem Token** — ein Phrasen-Eintrag, der das Wort nur enthält, ist fast nie die bessere Zuordnung als ein exaktes Einzelwort im Bestand, falls beides existiert.

Bulk-Insert: siehe eigener Abschnitt "Bulk-Insert bei großen Mengen" oben (dort ursprünglich für TUNICO entwickelt, gilt für jede große Quelle).

### Abgleich mit Derja Ninja (derja_ninja_entries)

Derja Ninja (derjaguru.com/derjaninja.com) ist eine tunesische Online-Wörterbuchdatenbank mit vokalisierten arabischen Einträgen, meist zuverlässiger vokalisiert als bestehende Trainer-Einträge. Offline-Dump: `derja_ninja_entries` (17.335 Zeilen, vollständiger Crawl aller Einzelwort-Seiten `/e/<uuid>` über die Sitemap, Stand 2026-08-17) — **die einzige zu verwendende Ninja-Tabelle**, `derja_ninja_import` (älter, 6.327 Wörter) wird seit 2026-09-02 nicht mehr verwendet, auch nicht als Fallback (siehe Abschnitt unten zur Begründung, warum sie trotzdem nicht gelöscht wird).

Spalten: `entry_uuid`, `arabic_script`, `darija` (Ninjas eigene Transliteration — andere Konvention, nie 1:1 übernehmen), `english`, `audio_url`, `term_start`/`term_end` (Sekunden-Offsets, direkt nutzbar), `example_arabic`/`example_darija`/`example_english`, `example_audio_url`, `example_term_start`/`example_term_end`, `pos_tag`, `scraped_at`, `translit_norm`/`translit_skeleton`/`arabic_skeleton` (vorab berechnete vokalfreie Skelette).

**Regel: arabic_script aus Derja Ninja bevorzugen**, auch bei kleinen Abweichungen — **aber erst, nachdem feststeht, dass es dasselbe WORT ist.** Buchstabengleichheit ist kein Wortnachweis: beim vollständigen Durchgang durch `vokalisierung_kandidaten` am 2026-09-15 waren **10 von 21 buchstabengleichen, eindeutig vokalisierten Treffern Homograph-Zufälle** — die Eigennamen نَجِيب (Najib) für `njib` „ich bringe" und سَمَر (Samar) für `smar` „er wurde braun", der osmanische Titel بَايْ (Bey) für das Lehnwort „bye", die Maß-II-Form تْكَوِّن „geformt werden" für تْكُون „sein", der Diminutiv صْغَيَّر für صغير, ein Verbalnomen تَفَاهُم statt des Verbs, das Verb كَتَبْ „to write" für den Nomen-Plural „Bücher". Pflicht vor der Übernahme: Ninjas `english` gegen unser `german` halten und Wortart/Verb-Maß prüfen (Lautlehre-Regel 5). Bei Zweifel ausschließen und mit `internal_note ~ 'ninja-vokalisierung verworfen'` festhalten. `darija` danach an die neue Form anpassen. `german`-Herkunftshinweis nur bei echtem Mehrwert ergänzen ((MSA)/(Darija)/(frz.)). `lesson_id` prüfen, bei Unklarheit Rückfrage. **Nicht automatisch ändern:** bereits korrekt vokalisierte Einträge mit nur orthographischer Variante bei Ninja; abweichende Bedeutung → als Auffälligkeit markieren, Nutzer entscheiden lassen; `darija` selbst wird nie aus Ninja übernommen (andere Konvention).

**Workflow Bestandsaudit (z.B. fällige unvokalisierte Vokabeln):**
1. **Exakt-Match-Scan:** `vocabulary.arabic_script` (unvokalisiert) direkt gegen `derja_ninja_entries.arabic_skeleton` (bereits vokalfrei, kein eigenes `regexp_replace` nötig). Vokalisierte Bestandseinträge: eigene Vokalisierung gegen `derja_ninja_entries.arabic_script` vergleichen (Lautlehre-Regeln 1–4 in SKILL.md, Imala-Abweichungen ignorieren).
2. Pro Vokabel: Anzahl distinkter `arabic_script`-Werte zählen, nicht Anzahl der `english`-Kandidaten — mehrere `english`-Formen (tomato/tomatoes, introduce/introduced/introducing) zeigen oft auf dieselbe Zeile (Kollektivnomen bzw. Lemma-Gruppierung, normal, kein Fehler).
3. Bei mehreren distinkten Vokalisierungen: Wortart/Bedeutung gegen die deutsche Übersetzung prüfen (Lautlehre-Regel 5, Maß-I/Maß-II-Falle — Praxisfall `yqaddem`: PRECEDENTS.md → derja_ninja_import). Nur bei eindeutiger Zuordenbarkeit übernehmen.
4. **Semantische Zufallstreffer filtern:** reine Konsonantenskelett-Kollisionen ohne inhaltlichen Bezug verwerfen, im Zweifel ausschließen.
5. Ergebnisliste mit Alt→Neu, English, Audio-Link (`audio_url`+`term_start`/`term_end`, kein Trimmen mehr nötig) zeigen, erst nach Bestätigung schreiben.
6. Nach der Ausführung: Stichprobe gegen Lautlehre-Regeln 1–4 gegenprüfen.

**Bekannte Grenzen:** deckt nur Exakt-Match auf Konsonantenskelett ab, Rest bleibt manueller Vokalisierungs-Workflow. "Kein Match" ist eine eigene Fehlerkategorie, kein Beweis für einen Vokabelfehler — harmlose Ursachen: Genus-/Numerus-Divergenz (Ninja listet oft nur die maskuline Grundform), regionale Synonymvielfalt (Ninja listet mehrere Dialektvarianten, unser Eintrag kann eine legitime weitere sein, die dort nicht auftaucht), reine Abdeckungslücke (Stichprobe: 3 von 10 alltäglichen Wörtern fehlten komplett im Offline-Dump — bei Unsicherheit immer live nachschlagen, `derja.ninja/search?search=...`).

`derjaninja.com` ist vollständig serverseitig gerendert — ein reiner curl-Abruf ohne JS liefert die komplette Ergebnisliste. Ein 403/leeres Ergebnis in einer anderen Session liegt an der Domain-Allowlist der jeweiligen Umgebung bzw. falschen Parameternamen (`search`, nicht `q`/`query`), nicht an fehlendem JS-Rendering.

**Live-Suche, wenn keine Offline-Quelle etwas liefert:** `GET https://derja.ninja/search?search=<begriff>&script=<english|transliterated|arabic>` (serverseitig gerendert, curl reicht, kein JS nötig). `script=english` für deutsche/englische Begriffe (vorher übersetzen), `script=arabic` für arabische Schreibung, `script=transliterated` für lateinische Umschrift. Kein Treffer → sauberer Text "No results".
- Jeder Treffer: `<div class="search-result__term_in_arabic">` mit `<audio src="https://static.derjaninja.com/recordings/NNNN.mp3">` und `<span class="transliterate-text">`. Beispielsatz-Block: `search_result__example_sentence_in_arabic` (Unterstrich statt Bindestrich — Inkonsistenz der Seite selbst).
- **Wort- und Beispielsatz-Audio zeigen oft auf dieselbe mp3** — Trennung passiert nur clientseitig per JSON-Zeitstempel (`{"term":{"start":...,"end":...}}`). `WebFetch` strippt dieses JSON — für Audio-Timing immer `curl` benutzen. `ninja_audio_url` nie ohne `ninja_audio_start`/`ninja_audio_end` setzen, wenn die Quelle ein Satz-Audio ist. Details/betroffene Fälle: PRECEDENTS.md → Abgleich mit Derja Ninja.
- Immer die volle Trefferliste scannen (bis zu 40 Treffer, nicht nach Relevanz sortiert), nicht nur die ersten 5–8.
- Audio-URL direkt beim ersten Scan mitextrahieren, nicht erst bei Bedarf.
- **Audio nur bei wirklich identischer Aussprache anhängen** — gleiche Silbenzahl, gleiche Gemination. صَرْف (sarf, "Wechselgeld") ≠ صَرِّفْ (sarrif, "wechseln") trotz gleichem Konsonantenskelett.
- Ein Treffer bedeutet nicht automatisch ein eigenes Headword — kann nur aus dem Beispielsatz eines fremden Eintrags stammen (typisch bei Redewendungen). Bei zusammengesetzten Begriffen ohne Treffer: nach dem Adjektiv/Bestandteil statt dem ganzen Kompositum suchen, und gezielt Beispielsätze durchsuchen.

**Ninjas eigener Transliterations-Schlüssel** (für `script=transliterated`-Suchen — Ninja konvertiert die Sucheingabe intern erst zu Arabisch):

| Ninja | Laut | Unsere Konvention | Für Ninja-Suche umwandeln |
|---|---|---|---|
| 2 | أ (Hamza) | meist weggelassen | – |
| 3 | ع | 3 | gleich |
| 5 | خ | kh | kh→5 |
| 7 | ح | 7 | gleich |
| 9 | ق | q | q→9 |
| ch | ش | sh | sh→ch |
| gh | غ | gh | gleich |
| h | ه | (kein eigenes Zeichen) | gleich |
| th | ث (immer) und ذ/ظ (in 64 % der Fälle) | th | gleich |
| dh | ض (immer) und ذ/ظ (in 38 % der Fälle) | dh bzw. th | **nicht umkehrbar** — siehe unten |
| a | Fatha (kurz) | a | gleich |
| i | Kasra (kurz) | i | gleich |
| ou | Damma (kurz) | oft u/o geschrieben | u/o→ou |

Beispiel: unser `yukhruj` → Ninja-Suche `you5rouj`; unser `yaqli` → `ya9li`. Bei `script=english`-Suchen nicht nötig. Langvokale schreibt Ninja `aa`/`iy`/`ouw`, ein `e` kommt in allen 17.335 Zeilen **kein einziges Mal** vor.

**Beim Lesen eines Ninja-Treffers (statt beim Suchen) gilt die Tabelle `SKILL.md` → Quell-Konventionen** — sie steht dort neben denselben Angaben für TUNICO und Peace Corps und sagt zusätzlich, welche Abweichung nur Konvention ist und damit kein Befund. Wichtigster Fall: Ninjas `dh` bei ذ/ظ ist **kein** Gegenbeleg gegen unsere `th`-Regel.

**Ninjas Transkriptions-Philosophie:** Ninja schreibt Wörter tendenziell in ihrer vollen, theoretischen Form (تحمص nicht اتحمص), orientiert sich bei Unsicherheit an der Hocharabisch-Schreibung — "volleres" Ninja-arabic_script ist meist keine Diskrepanz, nur eine andere Kontraktionsstufe. Bei sehr geläufigen Kontraktionen schreibt Ninja aber durchaus auch die kontrahierte Form — bei Widerspruch zwischen dieser Heuristik und einem konkreten Ninja-Treffer gewinnt immer der konkrete Treffer.

**Ninja zitiert Verben/Nomen in der Grundform** (Vergangenheit/Imperativ, nicht Präsens; Singular, nicht Plural) — Audio-Trefferquote bei Präsens-Verben und Pluralformen entsprechend niedrig erwarten, kein Recherche-Manko.

**Sobald ein Treffer die Schreibung bestätigt (kein Fehler), sofort auch das Audio mitziehen** — nicht nur die Rechtschreibprüfung als erledigt abhaken.

### derja_ninja_import — veraltet, nicht mehr verwendet

**Seit 2026-09-02 auf Nutzerwunsch abgelöst durch `derja_ninja_entries`** (17.335 statt 6.327 Zeilen, vollständigerer Crawl, mit Audio-Timing) — siehe Abschnitt oben für die aktuelle Methodik. Wird für keine neue Abfrage mehr benutzt, auch nicht als Fallback.

**Nicht löschen — kein reines Duplikat.** Vergleich am 2026-09-02: von 6.214 unterschiedlichen `darija_result`-Konsonantenskeletten in `derja_ninja_import` finden sich 1.186 (~19%) nicht in `derja_ninja_entries`. Stichprobe zeigt: größtenteils mehrwortige Phrasen/Redewendungen (z.B. "wallet"→"burtmuna", "classmate"→"wild klas"), keine fehlenden Einzelwörter — `derja_ninja_import` scheint eher Übersetzungs-Suchergebnisse (auch Phrasen) gescraped zu haben, `derja_ninja_entries` ist ein sauberer Wörterbuch-Eintrags-Crawl. Unterschiedlicher Zweck, kein Ersatz — Tabelle bleibt bestehen, auch wenn sie für neue Abfragen nicht mehr genutzt wird.

Tabelle: `english_word`, `darija_result` (vokalisiertes Arabisch), `samples` (jsonb-Array `{ar, en, audio_url}`), `source`, `imported_at`. RLS aktiv (Policy `app_access`). Zusätzliche Spalten in `vocabulary`: `english`, `ninja_id` (FK), `ninja_audio_url` (noch nicht im Trainer eingebaut).

Der ursprüngliche Workflow gegen diese Tabelle (zweistufige Zuordnung, Prioritäts-Batching) ist durch den `derja_ninja_entries`-Workflow oben vollständig ersetzt und hier nicht mehr dokumentiert. Ausgewählte Lehren, die weiterhin allgemein gelten (Maß-I/II-Praxisfall, harmlose "Kein Match"-Ursachen): PRECEDENTS.md → derja_ninja_import.

### speaktounsi.off (Instagram)

Eigene Transliteration — wird an unsere Chat-Alphabet-Konvention angepasst, nie 1:1 übernommen: Quelle schreibt 9 für ق, ţ für ط, ā für langes a → wir schreiben q, t, e/a; Quelle schreibt ch für ش → wir schreiben immer sh; Großbuchstaben (H, T, S) der Quelle für Emphase → wir schreiben 7, t, s; Vokale an bestehende Einträge angleichen (z.B. nmeshiw → nimshiw). Bei Unsicherheit: arabic_script als Anker, Partnerin fragen.

**Was immer aufgenommen wird:** Beispielsätze (auch wenn die Einzelvokabel schon existiert, als eigener Satz-Eintrag, Lektion "Gesprächsführung", topic=Phrasen/Ausdrücke), Sprichwörter (Lektion "Sprichwörter", topic=Sprichwörter), Vokabeln nur wenn arabic_script noch nicht in DB.

**Was nicht aufgenommen wird:** Eigennamen, Ortsnamen; zu 100% bereits Vorhandenes; Grammatikerklärungen ohne konkreten Satz/Ausdruck.

**Workflow pro Runde:** 4–5 Bilder hochladen → Extraktion + Duplikat-Check (3 Felder separat) → Tabelle mit Status (✅/⚠️ Fehlt/🔄 Satz neu) → Bestätigung abwarten → SQL-Block. Neues Gespräch nach ca. 10 Runden.

### Peace Corps English-Tunisian Arabic Dictionary (1977)

Zwei Supabase-Tabellen, Rohextrakt aus dem "Peace Corps English-Tunisian Arabic Dictionary" (Ben Abdelkader/Ayed/Naouar, 1977, ERIC ED183017) — ältere, sehr umfangreiche lexikografische Quelle, unabhängig von TUNICO/Uni-Wien/Derja-Ninja.

- **`peacecorps_dict_import`** (5.070 Zeilen — **komplett A–Z importiert**, kompletter Englisch→Tunesisch-Teil bis Seite 497; der umgekehrte Tunesisch→Englisch-Teil danach ist bewusst nicht importiert): `headword` (englisches Stichwort), `freq` (1–5, Häufigkeitsrang aus dem Original, keine Homonym-Nummer), `pos`, `forms_phonetic` (Array, Original-Lautschrift, Reihenfolge wie im Original: Sg./Pl., m./f./Pl., Imperativ/Perfekt — Groß-/Kleinschreibung markiert Emphase-Laute: H/S/T = ح/ص/ط vs. h/s/t = ه/س/ت), `forms_roles` (Array parallel zu `forms_phonetic`: `sg`/`pl`/`m`/`f`/`imperativ`/`perfekt`/`coll`/`"unklar"`, nicht befüllt bei `is_synonym_set=true`), `forms_chatalpha`/`forms_skeleton` (Arrays, aus `forms_phonetic` per Konvertierungsregel abgeleitet, siehe PRECEDENTS.md → Peace Corps forms_chatalpha/forms_skeleton; 5.004/5.070 befüllt, die restlichen 66 Zeilen haben schlicht kein `forms_phonetic`), `gender` (aus `pos` abgeleitet wo eindeutig), `is_loanword`, `is_synonym_set` (true = `forms_phonetic` sind echte unabhängige Synonyme, keine grammatischen Varianten), `needs_review` (unsichere Transkription — `false` heißt nicht "geprüft&sicher", nur "keine bekannte Auffälligkeit"), `senses` (jsonb, inkl. Beispielsätzen/Untersinnen), `arabic_script` (**bewusst leer**, nicht aus dem fehleranfälligen OCR übernommen — bleibt die einzige *unabhängige* Arabisch-Spalte dieser Quelle), `arabic_script_reconstructed`/`arabic_script_reconstruction_note` (**kein Faktum**: unvokalisierter Arabisch-Vorschlag aus `forms_phonetic[1]` per `public._pc_reconstruct_arabic()`, 4.874/5.004 rekonstruiert, davon 446 mit Unsicherheits-Hinweis; nie mit `arabic_script` verwechseln oder dort hineinschreiben — siehe PRECEDENTS.md → Peace-Corps-Arabisch-Rekonstruktion), `source_section`, `source_page`, `raw_text` (in der ganzen Tabelle 0% befüllt, kein Qualitätsproblem). Vor jeder Aussage zum Stand aktuell gegenchecken (`SELECT count(*), max(source_page) FROM peacecorps_dict_import`), nicht auf alte Notizen verlassen.
- **`peacecorps_grammar_import`** (21 Zeilen): `topic`, `page_start`, `page_end`, `raw_text`. Lautschrift-Legende (Sonderlaute Ḥ/ʕ/q, Vokalzeichen+Längung, Shadda) plus Grammatik-Kapitel (Personalpronomen, Artikel, Possessiv, Zahlen, Dual, Komparativ, Zeiten, Konditional, unregelmäßige Verben, Verneinung, Fragebildung, Objektpronomen). Rohmaterial für künftige `course_exercises`, noch nicht umgesetzt.

**Lautschrift lesen:** `forms_phonetic` benutzt Großbuchstaben für die Emphatika (`H`/`S`/`T` = ح/ص/ط), `x` für خ (nicht `kh`) und `:` für Langvokale (`thla:tha`); ذ/ظ fallen dort ausnahmslos auf `dh` zusammen. Vollständig neben den beiden anderen Quellen: `SKILL.md` → Quell-Konventionen.

**Nutzen beim Prüfen:** dritte Offline-Quelle in Schritt 3 (siehe SKILL.md → Der Prozess) — nach `derja_ninja_entries` und `tunico_import` durchsuchen, v.a. bei älterem/ungewöhnlichem Lehrbuchvokabular.

### Sprachenlernen24 — Tunesisch-Komplettpaket (gekaufter Kurs, seit 2026-11-01)

Privater, gekaufter Online-Kurs von Nils (Konto bei Sprachenlernen24; **Zugangsdaten gehören nie ins Repo oder in Chat-Notizen**, Rohdaten und Abruf-Skripte liegen nur im Arbeitsordner der Sitzung). Nur für Nils, nicht für Semia. Abruf am 2026-11-01 per Browser (Playwright, langsam, eine Sitzung); Stand wie bei Ninja/TUNICO: **feste Momentaufnahme**, ändert sich nur durch einen neuen Abruf.

- **`sl24_import`** (5.585 Zeilen): Vokabelteil, 126 Lektionen auf den Stufen A1–C2 (je 21). Spalten `niveau`, `lektion`, `lektion_titel`, `position`, `german`, `arabic`, `audio_url`, `saetze` (jsonb: `{ar, de, audio}`, insgesamt 25.035 Beispielsätze mit Übersetzung und Audio).
- **`sl24_inhalt`** (2.736 Zeilen): `bereich` = `dialog` (126 Lektionen, 1.832 Zeilen), `konversation` (21 Lektionen, 608 Zeilen), `grammatik` (92 Seiten Text), `land` (5 Länderinfos), `pdf` (199 Seiten aus drei PDFs: Arabisch-Kurzgrammatik, Arabische Grammatik, „Die wichtigsten Verben“ mit Umschrift). Zeilen mit `deutsch`/`arabisch`/`audio_url`, bei Text- und PDF-Seiten `text`.
- **Nicht geholt:** Satzbautrainer (benutzt die Dialogsätze), Online-Verbtrainer (steht im Verben-PDF), Lerntipps (allgemein, nicht tunesisch), Audiotrainer, Expresskurs und ZIP-Hörmaterial.
- Beide Tabellen sind privat (RLS an, kein Zugriff für `anon`/`authenticated`). Import ohne geheimen Schlüssel: Tabelle mit Insert-Richtlinie, die einen Geheimcode im Anfrage-Kopf (`x-import-token`) verlangt, dann PostgREST-Schnellimport mit dem öffentlichen Schlüssel; die Richtlinie danach per `drop policy` entfernen (Rückfrage im Editor, Nils führt aus).

**Wie belastbar:** Dritt- bis viertrangige Quelle, **keine Bestätigung allein**. Ein Autor, keine Quellenangaben, **keine lateinische Umschrift**, lockere Vokalisierung (Dehnstriche, verrutschte Zeichen, uneinheitliches Gaf `ق/ڨ/ﭬ`). A1/A2 sind echtes Tunesisch mit vielen französischen Lehnwörtern; **B2–C2 enthalten viel Hocharabisch**, die Grammatikseiten und die Arabisch-PDFs sind Hocharabisch (Musterverb *faʿala*). Belegwert: bestätigt ein Wort/eine Form nur zusammen mit Skript, TUNICO oder Ninja. Der Kurs hat sich im Abgleich einmal geirrt (*die Langeweile* = `القلق`, das heißt Sorge).

**Abgleich (2026-11-01):** 1.340 von 5.585 Kurswörtern (24 %) haben bei uns dasselbe Arabische (nach Normalisierung: Vokalzeichen, Artikel, Alif-Formen, `ق/ڨ/ﭬ`), 397 nur dasselbe Deutsche, der Rest ist neu. „Neu“ ist eine Obergrenze (Schreibvarianten fallen mit hinein). Nützlich als Fehlersuche für **Formen im Satz** (Plural, Verbformen): die 25.035 Sätze nach der Schreibung suchen, `jsonb_array_elements(saetze)`.

**Audio:** Die Aufnahmen sind **ohne Login öffentlich erreichbar** (Wörter unter `sprachenlernen24-onlinekurs.de/audio-tn…/NNNN.mp3`, Sätze der Extra-Audios unter `17min.io/Extra-Audios/audio-tn/tnNNN.mp3` – **diese Extra-Audios nicht verwenden** (Nils 2026-11-02, siehe COURSE_MODE.md → Hörübungen); nur die normale Serie wird wie Ninja-Audio verlinkt. Eintrag in die vorhandenen Felder `ninja_audio_url` / `_start` / `_end` / `audio_gain`, Start/Ende per Stille-Erkennung gemessen (Kurs-Dateien sind einzelne Wörter), `audio_gain` ≈ 0,0316 / RMS (der Trainer hebt nur Faktoren über 1 an; bei Kurs-Audio ist er daher ohne Wirkung), **Herkunft in `internal_note`** („Audio aus Sprachenlernen24 (Tunesisch-Komplettpaket)“). Zuordnung nur bei gleichem Arabisch **und** vereinbarer deutscher Bedeutung. Verben im Kurs stehen als 3. Person Präsens mit deutschem Infinitiv (`يكتب` = „schreiben“), das passt zu unseren *yiktib*-Zeilen. **Vorsicht:** Arabisch ohne Schadda trennt Formen wie *ytayyeb/ytib* oder *yti7/ytayya7* nicht; zeigen zwei Zeilen auf dieselbe Aufnahme, keine zuordnen. Falsche Treffer sind häufig (*sana* „Jahr“ ≠ „Zahn“, *jomal* ≠ „Kamel“): Ein-Buchstaben-Wörter und Treffer mit anderem Deutsch nicht blind übernehmen. Stand: 226 Vokabeln mit Kurs-Audio.

## Quellenabgleich (`quellen_abgleich`) — seit 2026-09-19

Loest den alten TUNICO-Kandidaten-Screen ab. **Die Vorschlagsliste wird nicht mehr gespeichert,
sondern bei jedem Öffnen berechnet** — Quellen minus Bestand minus Entscheidungsprotokoll.
`tunico_candidates` ist nur noch Altbestand und wird nicht mehr beschrieben.

**Warum:** `tunico_candidates.auto_verdict` und `.matched_vocab_id` waren ein Schnappschuss vom
8.–11. August 2026. Bis Mitte September waren 373 Vokabeln dazugekommen; **156 der 374 rot als
„fehlt“ markierten Zeilen waren längst vorhanden**. Dazu kam, dass die Grundgesamtheit auf
Top-300-Verben/Nomen und Top-64-Adjektive beschnitten war — das häufigste fehlende Wort des
Korpus (`kull`, 656×) konnte strukturell nie vorgeschlagen werden.

### Die Objekte

| Objekt | Art | Inhalt |
|---|---|---|
| `quellen_lemmata` | Materialized View, 22.356 Zeilen | eine Zeile je (Quelle, Lemma): tunico 2.005, peacecorps 4.043, ninja 16.308. `refresh materialized view` **nur nach einem Import** — 5,0 s |
| `vocab_tokens` | View | der Bestand auf Wortebene (5.826 Zeilen), Grundlage des `baustein`-Buckets |
| `quellen_abgleich` | **View, live** | die Vorschlagsliste mit Bucket und Score, 476 ms |
| `quellen_abgleich_zaehler` | View | die vier Bucket-Zahlen für die Chips im Trainer |
| `import_entscheidungen` | Tabelle | das Protokoll: was beurteilt wurde. `vocabulary_ids` ist ein **Array** — `sabb` passt auf #4508 „er beleidigte“ UND #4506 „er goss“ |

### Die vier Buckets

| Bucket | Bedeutung | Aktion |
|---|---|---|
| `fehlt` | weder eigene Zeile noch in einer Phrase | neu anlegen |
| `baustein` | steckt nur **innerhalb** mehrwortiger Zeilen | als Einzelwort nachziehen |
| `variante` | Skelett unterscheidet sich um **ein eingefügtes/fehlendes Zeichen** | Beleg auf die bestehende Zeile, keine Neuanlage |
| `vorhanden` | es gibt eine Zeile mit diesem Skelett | — |

**`baustein` ist die didaktisch wertvollste Gruppe:** sie schließt Phrasen auf, die schon im
Trainer stehen. `kull` steckt in 15 Phrasen (`kol youm`, `koll we7id w karhabtou`) und hat keine
eigene Zeile; `kif` genauso.

### Zwei Fallen, die beim Bau zugeschlagen haben

**Das Skelett ist die Vergleichsachse, nicht die Bündelungsachse.** Eine erste Fassung gruppierte
die Quelleinträge nach Skelett. Ergebnis: `kayyif` erschien mit der Korpushäufigkeit von `kif`
(480) und einer Glosse aus beiden Wörtern. Skelett `kf` fasst `kif`/`kayyif` zusammen, `st` fasst
`sawwit`/`sout`/`wast` zusammen. Einheit ist deshalb das **Lemma**; das Skelett vergleicht nur
gegen den Bestand.

**„Levenshtein ≤ 1“ ist für Konsonantenskelette zu weit.** Als `variante` so definiert war, bekam
`khrif` (Herbst) 27 „ähnliche“ Zeilen: `khraj` (er ging raus), `khfif` (leicht), `khater` (weil),
`nkhaf` (ich habe Angst). Formal alle Abstand 1. Der Grund ist sprachlich: **das Skelett besteht
nur aus Konsonanten, und im Arabischen tragen genau die die Wurzel** — ein getauschter Konsonant
ist fast immer ein anderes Wort. Eine echte Schreibvariante fügt dagegen ein Zeichen ein oder
lässt eines weg (`inshalla`/`inshallah`, `tlatha`/`thletha`); wo wirklich ein Laut anders
geschrieben wird (`th`/`dh`), sind es Digraphen und das Skelett ändert sich um **zwei** Zeichen.
`variante` zählt deshalb nur Längendifferenzen — danach 4.359 statt 5.890 Zeilen und im Schnitt
2,9 Kandidaten statt Dutzenden.

### Der Score

`ln(1+freq_korpus)*10` (Korpushäufigkeit) + `(6-rang_pc)*12` (Peace-Corps-Rang, 1 → 60)
+ `(n_quellen-1)*25` (Mehrfachbelegung) + 20 bei Ninja-Audio + 30 für `baustein`.
Alle Komponenten stehen einzeln als Spalten im View und hängen im Trainer als Tooltip an der Zahl.

**Die Mehrfachbelegung zählt erst ab Skelettlänge 4.** Kurze Skelette kollidieren zufällig
(`kanada` und `weekend` ergeben beide `knd`) — ein Wort über Zufallstreffer nach oben zu spülen
wäre genau der Fehler, den der Score vermeiden soll. Betroffene Zeilen tragen `kurzes_skelett`.

### Verben: immer zwei Zeilen

Der Trainer führt je Verb **zwei** Vokabeln (L17 Präsens, L18 Vergangenheit). Ein Verb als eine
Zeile anzulegen lässt die Hälfte fehlen.

**TUNICOs Lemma ist die Vergangenheitsform**, die Präsensform steht annotiert in
`tunico_import.inflected`:

```json
[{"ana": "#v_pres_sg_p3", "orig": "yṣaffaq", "chatalpha": "ysaffaq"}]
```

`#v_pres_sg_p3` = Verb, Präsens, Singular, 3. Person — 1.847 Einträge. **Ablesen, nicht raten.**
`tunico_corpus_verbs.forms_chatalpha` führt zwar auch Formen, aber unannotiert und
durcheinander (`fhimt, fhimt, fhimtu, ifhim, nifhm, nifhim, …`); der alte TUNICO-Screen brauchte
deshalb eine Rate-Funktion. Nicht mehr verwenden, wo `inflected` vorhanden ist.

Gegengeprüft an Paaren, die der Trainer schon führt: `7ka`/`ya7ki`, `3ayyit`/`y3ayyit`,
`nba7`/`yinba7`, `ghanna`/`yghanni`, `faqqas`/`yfaqqas`.

**Vorsicht:** das TUNICO-Lemma ist nicht immer eine Verbform — `b3id` führt der Trainer als
Adjektiv „weit/entfernt", `sarraf` als Nomen „Geldwechsler". Die Präsensform daneben
(`yib3id`, `ysarraf`) ist trotzdem korrekt. Also vorlegen, nicht automatisch anlegen.

### Beim Arbeiten damit beachten

- **Nie korrelierte `EXISTS`-Subqueries in diesen View bauen.** Die CTE-Struktur mit `LEFT JOIN`s
  ist kein Stil, sondern die Bedingung dafür, dass er live läuft: 476 ms gegen Timeout > 60 s.
- **`freq_ist_obergrenze`** heisst, die Häufigkeit stammt aus einem Mehrwort-Bündel und gehört
  dem Lemma nicht exklusiv (`kull shayy` und `7atta shayy` teilen sich 239).
- **`arabisch` kommt nur von Ninja.** TUNICO hat gar keine Arabisch-Spalte, Peace Corps nur
  Rekonstruktionen — die stehen bewusst **nicht** in dieser Spalte.
- **`gloss_de` ist ein Vorschlag**, keine fertige Lernübersetzung. Nur TUNICO liefert Deutsch
  (`senses→de`); der Trainer legt deshalb nichts ohne Bestätigung an.

### uniwien_source_pages

Tabelle `uniwien_source_pages` (270 Zeilen) — wörtliche Seiten-Transkription der Uni-Wien-Lehrskripte, eine Zeile pro PDF-Seite, per Claude Vision erfasst (Bild gelesen, nicht OCR). Spalten: `book`, `pdf_page`, `printed_page`, `lesson_number`, `section`, `content`, `has_nontext_content` (Flag für Seiten mit Bildern/Tabellen, von der Text-Transkription nicht vollständig erfasst), `transcribed_by`, `transcribed_at`.

**Das ist die Rohdaten-Ebene, von der `course_lessons.grammar_notes`/`dialog_text` und `course_exercises` abgeleitet wurden** — getrennt gehalten, damit sich Vollständigkeits-Audits gegen den tatsächlichen Quelltext prüfen lassen, nicht nur gegen die bereits verarbeitete Zusammenfassung. **Für Kurs-Vollständigkeits-Audits (siehe COURSE_MODE.md → Pflichtschritt: Item-Zählung) die belastbarste Quelle** — `content` (nach `lesson_number`/`pdf_page` gruppiert) gegen die tatsächlich in `course_exercises` vorhandenen Items abgleichen, statt sich nur auf `grammar_notes`/`dialog_text` zu verlassen. `has_nontext_content=true` markiert Seiten mit möglicherweise unvollständiger Transkription — dort vor einer "vollständig geprüft"-Aussage die Originalquelle nochmal gegenprüfen.
