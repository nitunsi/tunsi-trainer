# Tounsi Trainer — Kurs-Modus & App-Code

Regeln für den Lektionen/Stepper-Bereich des Trainers (`course_lessons`/`course_exercises`) und für Änderungen an `trainer.html` selbst. Hat mit Vokabel-Prüfung/-Anlage nur am Rande zu tun (Vokabeln werden dort per ID verlinkt, nicht neu bewertet) — nur bei Bedarf nachschlagen, wenn tatsächlich am Kurs-Feature oder am App-Code gearbeitet wird. Kern-Regeln zu Vokabeln selbst stehen in `SKILL.md`.

## Code-Änderungen

- Nicht einbauen ohne Bestätigung
- Syntax-Prüfung via `node vm.Script()` vor Auslieferung
- Output-Datei immer `trainer.html` (ohne Versionsnummer) — Ausnahme: bei Android-Caching-Problemen Versionsnummer erhöhen
- **Neue Prüfung oder Prüfregel?** Gehört in den Trainer (`datenChecks()`), wenn dessen geladene Daten reichen — Abschnitt „Prüfungen im Trainer“ in SKILL.md; erst Trefferzahl mit echten Daten im Node-Harness berechnen, dann vorschlagen
- **Bei Performance-Fixes (z.B. fehlendes `spellcheck="false"`) alle Geschwister-Inputs im selben Formular mitprüfen, nicht nur das gemeldete Feld** (Präzedenzfall: PRECEDENTS.md → Code-Änderungen)

## Offline und schneller Start (seit 2026-10)

- **`sw.js`** (Wurzel, Scope `/`): speichert nur die App-Hülle (`trainer.html`, `neu/neu.css`, `neu/neu.js`, Manifest, Symbole, Schriften). Navigation und `neu/*`: Netz zuerst (3 s), sonst Zwischenspeicher. Nur GET der eigenen Herkunft – nie Supabase, nie Audio, nie Schreiben. Neue Version = Hinweis „Neue Version – neu laden“, nie stilles Einspielen. **Neue Datei unter `neu/`?** Dann in `CORE` in `sw.js` eintragen, wenn sie offline gebraucht wird.
- **Lese-Cache** (IndexedDB `tounsi_cache`, in `trainer.html` Abschnitt „LESE-CACHE“): hängt in `sbApi`/`sbApiRangeFirst`; nur Pfade aus `rcCacheable()` (Vokabeln, Fortschritt, Kurs, Lektionen, users). Neuer Lese-Pfad, der offline gebraucht wird → dort eintragen. `review_log` bewusst nicht gecacht.
- **Start aus dem Zwischenspeicher** (`_rcMode='cache'`): Startseite sofort, danach `rcRefresh()` im Hintergrund (Zwischenspeicher füllen) und `rcApplyIfIdle()` (übernehmen nur auf der Startseite, nie mitten in einer Übung). Nicht gesendete Antworten werden über den Stand gelegt (`oqOverlayVocab/Course`).
- **Schreiben:** nur über die Offline-Queue. Kurs-Fortschritt (`type:'course_progress'`) und Kurs-Protokoll laufen jetzt ebenfalls über die Queue.
- **Schriften** liegen in `neu/fonts/` (selbst ausgeliefert, `immutable`). `berlinDayKey` nutzt einen gemeinsamen `Intl.DateTimeFormat` (vorher ~2,6 s Startzeit auf einem langsamen Gerät).

## Erinnerung per Web-Push und Badge (seit 2026-10)

- **Server (Supabase `lzecflvfalxkodytnwzf`):** Tabelle `push_subscriptions` (user_id, endpoint, p256dh, auth), Edge Function `due-reminder` (nur für Nutzer `Nils`; zählt `progress` + `course_exercise_progress` mit `next_review` bis Ende des Berliner Tages; höchstens ein Push pro Tag über `users.last_reminder_sent_at`), Cron-Job `due-reminder-daily` täglich 05:00 UTC (06:00 Sommer / 07:00 Winter). Secrets: `VAPID_PUBLIC`, `VAPID_PRIVATE`, `CRON_SECRET`.
- **Client:** `neu/neu.js` Abschnitt „Erinnerung (Web-Push) und Badge“ (`neuTogglePush`, `neuBadge`, Schalter unter Mehr → Konto, nur für Nicht-Partner); `sw.js` Handler `push` und `notificationclick`.
- Der Server zählt rohe `next_review`-Zeilen, der Trainer blendet gesperrte Vokabeln aus (`isQueueBlocked`) — die Zahl in der Meldung kann daher etwas höher sein als die Anzeige im Trainer.
- iPhone: Push nur mit App auf dem Home-Bildschirm (iOS ≥ 16.4).

## Kurs-Modus: course_lessons / course_exercises

Der Trainer hat neben der klassischen SRS-Vokabelabfrage einen Kurs-Modus, aufgebaut aus den Uni-Wien-Lehrskripten. Drei Tabellen:

- `course_lessons` — eine Zeile pro Lektion, mit `grammar_notes` (Markdown, `### Überschrift`-Abschnitte) und `chunk_order` (jsonb-Array: Reihenfolge/Gruppierung — jedes Element hat `key`, `label`, `dialog`, `grammar_headings`)
- `course_exercises` — eine Zeile pro Übungs-Item, mit `course_lesson_id`, `position` (Integer, Reihenfolge), `chunk_key` (muss zu einem `key` in `chunk_order` passen), `exercise_type`, `prompt`, `solution`, optional `vocabulary_id`
- `course_exercise_progress` — SRS-Fortschritt pro Nutzer/Übung (seit 2026-09, siehe Abschnitt "Kurs-SRS" unten). `course_progress` (Fortschritt pro Nutzer/**Lektion**) existiert als Altlast der früheren Stepper-UI weiter in der DB, wird vom aktuellen Code aber nur noch vom (praktisch toten) Test-Tab für nicht gechunkte Lektionen geschrieben — nicht mit `course_exercise_progress` verwechseln.

**Bei jeder Tabelle, die über die Zeit wächst, `sbApiPaged` verwenden, nicht `sbApi`** — PostgREST liefert standardmäßig max. 1000 Zeilen pro Request, unabhängig vom `select`. Ein einfacher `count(*)`-Check gegen 1000 ist ein guter Kurz-Test, wenn ein Nutzer "fehlende Inhalte" meldet, obwohl die DB sie zeigt (Präzedenzfall mit ~270 verlorenen Übungen: PRECEDENTS.md → Kurs-Modus).

### Kurs-SRS (seit 2026-09) — ersetzt den alten Chunk-Stepper

Hintergrund: Vokabellernen ("einfach abarbeiten") fiel leichter als der Kurs, weil der Kurs erzwang, eine ganze Lektion am Stück im Stepper durchzugehen. Der alte Stepper (Chunk-Übersicht → Chunk-Intro → Items → Chunk-Zusammenfassung, schrieb in `course_progress`) ist komplett entfernt (`courseStartStepper`, `renderCourseStepperTab`, `courseStep*`, `renderStepPicker` existieren nicht mehr). Ersetzt durch:

- **Eigenes SRS pro Übung** (`course_exercise_progress`: `user_id`, `exercise_id`, `correct_count` als Level 0–6, `wrong_count`, `review_count`, `next_review`, `last_reviewed`, `last_correct`) — Stufen-Logik 1:1 wie beim Vokabel-SRS (`SRS_DAYS=[1,1,3,7,14,30,90]`, falsch → sofort zurück auf Level 0 & sofort wieder fällig). Implementiert in `courseExAnswer()`, gespiegelt von `srsAnswer()`. Rührt `progress`/`srsProgress` (Vokabeln) nirgends an — komplett getrennter Zustand.
- **SRS-fähige Exercise-Typen** (`COURSE_SRS_TYPES`): `translate_de_tn`, `fill_blank`, `answer_pattern`, `grammar_drill`, `fixed_response`. Ausgeschlossen: `pronunciation` (läuft weiter über das Vokabel-SRS via `vocabulary_id`), `grammar_card` (reine Merkkarte, nur über den Grammatik-Button erreichbar, siehe unten), `build_dialog` (keine feste Lösung).
- **Freischaltung chunk-weise, ein Chunk auf einmal**: `courseFlattenChunks()` legt alle Lektionen (nach `course_number`) und ihre Chunks (nach `chunk_order`) zu einer globalen Reihenfolge flach. `courseEnsureFrontierUnlocked()` schaltet höchstens einen weiteren Chunk frei — erst wenn der vorherige zu ≥90% auf Level ≥3 ist (`courseChunkMastered()`; ursprünglich Level ≥4, am 2026-09-08 auf 3 gesenkt — bei Level 4 dauerte selbst ein kleiner Chunk ~11 Tage bis zur Freischaltung des nächsten, das war als reine Freischalt-Hürde zu konservativ). Freischalten = für alle SRS-fähigen Übungen des Chunks eine `course_exercise_progress`-Zeile mit Level 0 anlegen (`courseUnlockChunk()`). Läuft nach jedem `loadCourseData()` und nach jeder beantworteten Übung (`courseExAnswer()` → `courseEnsureFrontierUnlocked()`). Zusätzlich manuell möglich: in der Lese-Ansicht hat jeder gesperrte Chunk einen "🔓 Diesen Abschnitt jetzt freischalten"-Button (`courseManualUnlockChunk()`) — schaltet unabhängig von der automatischen Reihenfolge sofort frei, für gezieltes Vorspringen.
- **Drei Einstiegspunkte** im Nav (`setMode`): `flash` = reine Vokabelkarten (unverändert), `coursesrs` = nur fällige Kurs-Übungen (`goCourseSrs()`/`bCourseSrs()`), `mix` = fest 8 Vokabeln + 2 Kurs-Übungen pro Runde, bei zu wenig fälligen Kurs-Übungen mit Vokabeln aufgefüllt (`goMix()`/`bMix()`). Alle drei laufen über denselben bestehenden Übungsmotor (`exList`/`cIdx`/`render()`/`nxt()`/`showRes()`) — Kurs-Karten sind darin `ex.type==='course'`, gerendert von `rCourseEx()`.
- **Grammatik-Button** (`showGrammarModal()`) auf jeder Kurs-Karte: zeigt Dialog/Grammatik des zugehörigen Chunks (`courseGrammarModalContent()` → `courseChunkLearnHtml()`) als Bottom-Sheet, unabhängig von der aktuellen Abfrage.
- **Lese-/Browse-Ansicht** (`renderCourseBrowseTab()`, Tab "📖 Ansicht" innerhalb einer Lektion): zeigt alle Chunks einer Lektion inkl. Lock-Status (🔒/🟡/✅/📄) und Level-Badge pro Übung (`courseExLevelBadge()`) — Inhalt ist **immer lesbar**, auch für noch nicht freigeschaltete Chunks (bewusste Nutzerentscheidung, 2026-09-08). Ersetzt den alten Chunk-Stepper als Tab-Inhalt (Tab-Key bleibt `'course'`, nur das Ziel-Rendering hat sich geändert).
- **Kurs-Übersicht** (`renderCourseOverview()`, Lektionsliste): Status/Icon jetzt aus `courseFlattenChunks()` berechnet (Anteil gemeisterter SRS-Übungen), nicht mehr aus `course_progress.status`. Alle Lektionen sind dort immer öffenbar (keine Lock-Buttons mehr auf dieser Ebene — Sperre existiert nur auf Chunk-Ebene, sichtbar in der Browse-Ansicht).

### Statistik-Screen: Vokabeln und Kurs sind zwei Blöcke, der Anfänger-Puffer ist einer

`showStats()` hält die Zählungen bewusst getrennt (`levelCount`/`dueDays` für Vokabeln, `courseLevelCount`/`courseDueDays` für den Kurs) und zeigt zwei Fortschrittsblöcke — eine gemeinsame Prozentzahl aus zwei unterschiedlich weit fortgeschrittenen Beständen wäre wenig aussagekräftig. Die Kurs-Arrays sind nur bei `cLesson === 'all'` befüllt (`course_lessons` bildet nicht 1:1 auf Vokabel-Lektionen ab).

**Ausnahme: die Warnung "Anfänger-Puffer wird knapp" zählt beide Quellen zusammen** (2026-09-15). Sie ist kein Fortschrittsmaß, sondern die Frage "geht mir der Anfängerstoff aus?" — und die beantwortet sich nur über den gesamten täglichen Abfragestrom, den der Mix-Modus ohnehin mischt. Vorher zählten nur Vokabeln: bei 53 Vokabeln in L0–L2 schlug sie an, obwohl 35 Kurs-Übungen danebenstanden, zusammen also 88. Der Trigger bleibt der gewichtete Puffer (`phaseAnfaengerWeighted`, L0=3/L1=2/L2=1 verbleibende Schritte bis L3, Schwelle < 25), rechnet aber über `levelCount[i] + courseLevelCount[i]`. Er steht deshalb im Code **nach** dem Kurs-Block, nicht mehr bei den Vokabel-Lernphasen, und die Warnung hängt über beiden Blöcken statt in der Vokabel-Box. Die vier Kacheln (Neu/Anfänger/Fortgeschritten/Profi) bleiben pro Block getrennt.

Level in beiden Welten identisch abgeleitet: `Math.min(correct_count, 6)`; Bucket 0 ist "nie gestartet" (bei Vokabeln: kein `progress` **oder** `next_review IS NULL`; beim Kurs: keine `course_exercise_progress`-Zeile, also noch gesperrt).

### Exercise-Typen

| Typ | Verwendung |
|---|---|
| `translate_de_tn` | Deutsch → Tunesisch übersetzen, `prompt`=Deutsch, `solution`=Tunesisch |
| `fill_blank` | Lückentext, `___` im prompt |
| `answer_pattern` | Frage + Musterantwort(en), oft `ih, X. / la, Y.`-Format |
| `fixed_response` | Feste Grußformel-Paare (Frage→Antwort) |
| `grammar_drill` | Konjugationstabellen, Possessivsuffix-Reihen — `solution` listet alle Formen |
| `grammar_card` | Reine Erklärkarte (Frage zur Grammatik → Erklärung als Antwort) |
| `build_dialog` | Wort-Paare/-Tripel zum freien Dialogbau, `solution` oft `null` |
| `pronunciation` | Einzelwort-Ausspracheübung — **muss `vocabulary_id` verlinkt haben** (inkl. Audio, wenn vorhanden) |
| `listening` | Hörverstehen (seit 2026-11): `meta.audio_url` = Aufnahme (https), `prompt` = arabischer Text (bleibt bis „Lösung zeigen“ verborgen), `solution` = deutsche Bedeutung, `meta.beleg` = `sl24`. Selbstbewertung wie `fixed_response`, in der Kurs-Wiederholung. Die Prüfung „Hörübung ohne Aufnahme oder ohne Text“ im Trainer fängt fehlende Felder |

### Konjugationskarten: `meta` und die Verknüpfung zur Vokabeltabelle (seit 2026-11)
Karten „(Perfekt/Präsens konjugieren)“ (`grammar_drill`) tragen in `meta`: `regel` (Verbklasse; Perfekt `reg`, `primae`, `gem`, `tert`, `med`, `ii`, `ii_schwach`, `ii_gem`, `iii`, `v`, `vi`; Präsens `p_…`), `gruppe` (1–6), `verb_de`, `verb_pres`, `ar` (arabisches Wort der Er-Form mit Vokalzeichen, der Hinweis zeigt daraus die Buchstaben), `hinweis` (Freitext), `beleg`.

- **`meta.vocab_id`** verweist auf die Vokabel, deren `conjugation` die Formen der Karte führt (die Zeile, deren `darija` der Prompt ist). Absichtlich **nicht** `course_exercises.vocabulary_id`: dort hängen Audio, Lernstand und der Löschschutz dran.
- **`meta.abw`** = gewollte Abweichung `{"<Personenschlüssel der Tabelle>": "<Form der Karte>"}`, z. B. `{"3sg_f": "waqfit"}`, wenn Skript und TUNICO anders schreiben als die Vokabel.
- **Anzeige (Stufe 2, `konjAusVokabel` vor `courseConjView`):** Mit `meta.vocab_id` zeigt die Karte die Formen aus `conjugation` der Vokabel (Perfekt = `past`, Präsens = `present`), nicht aus `solution`; `meta.abw` ersetzt einzelne Zellen. Ohne Verknüpfung, ohne Tabelle oder ohne die Zelle bleibt die Form aus der Lösung. `solution` bleibt als Rückfallebene stehen und wird von der Prüfung unten gegen die Tabelle verglichen.
- Die Prüfung steht im Trainer (*Mehr → Prüfungen*: „Kurskarte weicht von der verknüpften Vokabeltabelle ab“, `translitExtraChecks0`, Punkt 5b). Sie vergleicht je Zeit (Perfekt/Präsens) die Formen der Karte mit der Tabelle; -et/-at gelten als gleich. **Korrigiert wird zuerst die Vokabeltabelle**, dann die Karte; nur wenn die Karte bewusst anders schreibt, kommt `meta.abw` dazu.
- Neue Karten: `meta.vocab_id` setzen, sobald es zum Verb eine Vokabel mit Tabelle gibt. Ohne Tabelle bleibt die Lösung der alleinige Bestand.

### Regelkarten: `meta.layout = 'regelkarte'` (seit 2026-11)
Merkkarten zu Verb- und Partizipregeln (`answer_pattern`, `source` `constructed`), Daten in `meta.regelkarte`: `verb` {ar, tr, de}, `frage`, `ant` {ar_von, tr_von, ar_nach, tr_nach, de_nach}, `formel`, `tabelle` {kopf, zeilen}, `schritte`, `text`, `sicher`, `erklaerung` („Genauer erklärt“: Warum + Beispielsatz mit Deutsch), `bsp` [{…von/nach…, de, ausnahme}]. **Jede Form bekommt Deutsch** (Nils 2026-11-07): `verb.de` (bei mehreren Verben alle, mit „ · “), `ant.de_nach`, `bsp[].de` (Bedeutung der Zielform), Verben in `schritte` mit „…“-Übersetzung. Die Trainer-Prüfung „Regelkarte ohne Deutsch oder Erklärung“ meldet Lücken. Nur `**fett**` wird dargestellt, keine einfachen Sternchen. **Fachwörter** (Wurzel, Stamm, Stammvokal, Perfekt, Präsens, Partizip, geminiert, schwaches Ende, Hohlverb, Kehllaut, Imperativ) werden im Trainer automatisch unterstrichen und sind antippbar (Kurzerklärung); die Erklärungen stehen **einmal** in `GLOSSAR` (`trainer.html`) und auf der Seite *Mehr → Glossar*. Im Kartentext nichts markieren; ein neues Fachwort nur dort eintragen. Kartentexte setzen den Begriff nicht noch einmal ausführlich, höchstens ein Satz zum konkreten Stamm. `meta.beleg` = `belegt` oder `abgeleitet`, `meta.karte` = Kürzel (A1, P2, H1 …, je Lektion eindeutig).
- **Abschnitte:** `partizip_regeln` (L5), `perfekt_praesens_a/b` (L10), `verbtypen_regeln` (L6–L11), jeweils in `chunk_order` hinter den Grammatik-Abschnitt gesetzt, zu dem sie gehören; Positionen 11xx/12xx.
- **Freischalten** = `course_exercise_progress`-Zeile je Karte (0/0/0, `next_review now()`), bestehende nicht überschreiben.
- **Prüfung im Trainer** (`datenChecks`, „Regelkarte: Arabisch passt nicht zur Umschrift“): vergleicht jedes ar/tr-Paar aus `verb`, `ant`, `bsp` über `transliterateArabicWord`. Bei Beispielen mit Präfix auf das Vokalzeichen achten (يِنْجَح yinja7, nicht يَنْجَح; يْرُدّ yrudd).
- Regelkarten sind von der Prüfung „Wort in Aufgabe, aber erst in einer späteren Lektion verknüpft“ ausgenommen (Beispielverben zum Nachschlagen).
- Ändert sich ein Beispielwort in den Vokabeln, die Karte mitziehen (SKILL.md → Folgeorte, Punkt 6): `meta.regelkarte` **und** `solution` (enthält Text und Beispiele noch einmal als Klartext).

### Workflow: erst Vokabeln, dann Übungen

Standing rule: **bei jeder neuen Lektion erst alle referenzierten Vokabeln vollständig gegen den Bestand prüfen und importieren, danach erst die Übungen bauen.** Nicht vermischen. Jede Einzelwort-Übung (v.a. `pronunciation`) wird mit der Vokabel per `vocabulary_id` verlinkt, inkl. Audio wenn vorhanden.

**Nach jeder neuen Verknüpfung oder Neuanlage von Vokabeln immer prüfen, ob sich Audio ergänzen lässt** (Nutzeranweisung 2026-11-01): die betroffenen Vokabeln ohne `ninja_audio_url` gegen Ninja (wortgleich) und Sprachenlernen24 (`sl24_import`, `sl24_inhalt` Konversation/Dialog; Arabisch gleich nach Artikel-/Vokalzeichen-Normalisierung, Bedeutung passt) abgleichen; Treffer mit Start/Ende/Lautstärke messen und als Vorschlag zeigen — erst nach Bestätigung schreiben. Gleiche Schreibung kann ein anderes Wort sein (`sana` Jahr ≠ السنّة Zahn), deshalb die Bedeutung lesen. Vor dem Anlegen eines „fehlenden“ Worts auch nach Schreibvarianten (Hamza, ص/س, ة) und nach der deutschen Bedeutung suchen; Beispiele, die es schon gab: `shkoun` (أشكون), `sama7ni`, `esh-shatt`, `el beqi`, `ena manish`.

Bildbasierte Übungen werden nie umgesetzt — explizite Anweisung "Bild rausnehmen". Beim Auswerten kurz vermerken, welche Übungsnummern deshalb übersprungen wurden.

### Pflichtschritt: Item-Zählung, nicht nur Abschnitts-Existenz

**Prüfen ob eine nummerierte Übung existiert reicht nicht — alle Items bis zur letzten Nummer müssen als eigene `course_exercises`-Zeile in der DB stehen.** (Präzedenzfall mit ~50 übersehenen Übungen über drei Lektionen: PRECEDENTS.md → Kurs-Modus.)

1. Jede nummerierte Übung im Quellmaterial bis zur letzten Ziffer durchzählen (z.B. "V. Übersetzen Sie, 1–21" → 21 Items erwartet)
2. Gegen `SELECT count(*) FROM course_exercises WHERE course_lesson_id=X AND chunk_key='...'` abgleichen
3. Bei Abweichung: fehlende Items identifizieren, nicht "ist wohl vollständig" annehmen
4. Auch mehrseitige Übungen beachten — Nummerierung kann über einen Seitenumbruch weiterlaufen

### Vollständigkeitsprüfung: Vokabel-Verknüpfung pro Lektion (vocab_lesson_refs)

**Nie nach `vocabulary.topic` prüfen, ob eine Vokabel zu einer Kurs-Lektion gehört — das Wort muss wirklich im Kurstext vorkommen (Nutzeranweisung, 2026-09-02).** Ein Themen-Sweep erzeugt massive Fehlalarme: bei einem Testlauf lieferte er für 11 Lektionen zusammen ~280 scheinbar fehlende Vokabeln, von denen nach Volltext-Prüfung nur eine kleine Minderheit echt war.

**Richtige Methode:**
1. Korpus pro Lektion zusammenbauen: `dialog_text` + `grammar_notes` + **alle** `course_exercises`-Felder (`instruction`, `prompt`, `solution`, `meta::text` — nicht nur `prompt`/`solution`, sonst gehen Treffer aus Drag&Drop-Wortlisten verloren).
2. Kandidaten (grob per `topic` vorsortiert, um die Menge klein zu halten) mit Wortgrenzen-Regex (`\y...\y`, NICHT `\b`) gegen den Korpus matchen.
3. **Pflicht-Gegencheck pro Treffer:** Fundstelle im Korpus tatsächlich lesen. Kurze/häufige Wörter sind anfällig für Homograph-Kollisionen — ein Treffer beweist nur, dass die Zeichenkette vorkommt.
4. Nur bei bestätigtem Treffer die ID (und ggf. das Wort im `darija:`-Teil) an `vocab_lesson_refs` anhängen — nie den ganzen String überschreiben.

**Wiederkehrende Homograph-Fallen (immer den tatsächlichen Fundtext lesen):**

| Zeichenkette | Falsch angenommene Bedeutung | Tatsächlich meist gemeint |
|---|---|---|
| `dar` | er drehte sich / er wandte sich | `dar` = Haus ("f-id-dar" = zuhause) |
| `mit` | ich starb | deutsches Wort "mit" in Erklärungs-/Übersetzungstexten |
| `3am` | er schwamm | `3am` = Jahr |
| `walla` | er wurde | `walla` = oder (Konjunktion) |
| `kan` | er war | Bedingungspartikel "falls/wenn" (`kan, idha, idha kan`), v.a. in Grammatik-Abschnitten zu Bedingungssätzen |
| `sghar` | Kinder (Nomen) | Plural von `sghir` = klein (Adjektiv) |

Liste nicht abschließend — bei jedem neuen kurzen/häufigen Treffer denselben Verdacht anwenden.

**Präzedenzfall 2026-09-02: L1–L13 systematisch geprüft**, ~132 echte Verknüpfungen ergänzt, ~15 Fehlalarme aussortiert. Bei L11/L13 auf Nutzerwunsch ohne `progress.next_review`-Fälligsetzung (nur Verknüpfung, kein SRS-Eingriff) — bei künftigen Lektionen im Zweifel nachfragen. Nicht erneut von null anfangen, sondern bei neuen/geänderten Lektionen gezielt ergänzen.

### Kurs-Texte: Pronomen, Transliteration, Übersetzungs-Anhang

- **Pronomen** in Kursübungen richten sich nach den Vokabeln (`ena`, nicht `ana`). `ana` als **Fragewort** („welche/wo“) nicht ersetzen. Beim Angleichen die Raster der Konjugationsübungen mitprüfen (`GRAMMAR_DRILL_PERSONS` im Trainer).
- **Transliteration** der Kurs-Übungen nach den Trainer-Regeln (ح = `7`, ع = `3`, `najjim` = können); Uni-Wien-Umschrift (ḥ, ʕ, š …) nicht übernehmen.
- **Übersetzung anhängen:** nie mit ` — ` an eine textgeprüfte Lösung (`translate_de_tn`, `fill_blank`) hängen, sofern `courseSolutionCore` nicht greift. `answer_pattern` nutzt `Tounsi (Frage — Antwort)`, `fixed_response` bekommt die Übersetzung in `meta.prompt_de`/`meta.solution_de`.

### Wortvarianten nicht vorschnell auf Bestandswort normalisieren

Vor dem Zusammenlegen zweier ähnlicher Wörter prüfen, ob eine Übung selbst eine phonetische Eigenheit der exakten Schreibweise demonstriert (Artikel-Assimilation, Reim, Wortspiel) — wenn ja, nicht mergen, beide Formen behalten, im Zweifel Nutzer fragen (Präzedenzfall `dziri`/`jzayri`).

### `chunk_order` — Sync-Pflicht mit `grammar_notes`

**Technischer Zwang:** `chunk.grammar_headings` referenziert `### Überschrift`-Text aus `grammar_notes` per **exaktem String-Match** (`parseGrammarSections()` in trainer.html). Wird eine `###`-Überschrift umbenannt/zusammengelegt, MUSS jedes referenzierende `chunk_order`-Element mitaktualisiert werden — sonst bricht die Verknüpfung lautlos (kein Fehler, der Intro-Screen zeigt einfach nichts). Auch bei jeder Konvention-Änderung (z.B. Transliterationsregel) `chunk_order`-Labels mit durchsuchen, nicht nur `grammar_notes`/`vocabulary`.

### Hörübungen aus Sprachenlernen24: Auswahl und Prüfung (seit 2026-11)

Material für `listening` nur aus der **normalen** SL24-Serie (`audio-tn1/tn3/tn5/tn7`, Einzelphrasen und Dialogzeilen), **nie aus `Extra-Audios`** (`17min.io/Extra-Audios/…` und `sprachenlernen24-onlinekurs.de/Extra-Audios/…`: Männerstimme mit falscher Betonung, keine Verlagskennzeichnung, im Oktober 2026 neu erzeugt, vermutlich Computerstimmen; Nils hat 10 Beispiele gehört und sie verworfen, 2026-11-02: „besser als die falsche Aussprache, aber kein Vergleich zu den restlichen“). Das gilt auch für Vokabel-Audio und die Audio-Sicherung (`tools/audio_sichern.py` lässt sie ohne `--mit-extra` weg). Wörter allein bringen nichts: **kurze ganze Sätze, eher 6 bis 8 Wörter als 3**, Tempo prüfen (Buchstaben pro Sekunde ohne lange Pausen; deutlich unter dem Median = zu langsam, weglassen). Reihenfolge wie bei jeder Lektion: **erst alle Wörter des Satzes als Vokabeln vorhanden und mit der Lektion verknüpft** (Konjugationsformen als eigene Zeile, Namen wie Abdallah ausgenommen), dann die Übung. Gleiche Bedeutung wie ein vorhandenes Wort heißt `homonym_ok` auf allen Partnern (nicht doppelt anlegen, außer Nils will zusammenführen).

**Übersetzung gegen die Vokabeln prüfen, bevor die Übung angelegt wird** — die SL24-Übersetzungen sind nicht verlässlich: Jedes Wort des arabischen Satzes gegen unsere Vokabeln lesen und mit dem deutschen Satz vergleichen. Gefundene Fehler (2026-11-01): `كحل` = schwarz statt „blau“, `غدوة` = morgen statt „morgens“, `العظم المقلي` = Spiegelei statt „Rührei“, ergänzte Wörter („Flug“, „fliegen“ für `تسافر`). Nils-Feedback: wenn ihm eine Übersetzung falsch vorkommt, stimmt das.

**Aufnahmen auf Inhalt prüfen** lässt sich mit einer Spracherkennung (`faster-whisper`, Modell `medium`, Sprache `ar`, über ffmpeg nach 16-kHz-Mono dekodiert und als Array übergeben, sonst scheitert `av.open`): Das Modell ist auf Hocharabisch trainiert und schreibt Tunesisch nur ungefähr, reicht aber, um zu sehen, ob **dieselben Wörter** gesprochen werden wie im Text. Vorgehen und Ergebnis (4 Prüfaufnahmen, alle stimmen) in der Notiz der Übung ist nicht nötig; bei Zweifel mit dem Modell nachhören.

### Herkunft der Abschnitte (seit 2026-11)

Kurs-Übersicht → Knöpfe **Alle / Uni Wien / Selbst gebaut / SL24** (Auswahl in `localStorage` `course-herkunft`). Die Herkunft eines Abschnitts kommt aus `chunk_order`: Feld `herkunft` (`uniwien` | `constructed` | `sl24`) gewinnt, sonst abgeleitet — Dialog oder `grammar_headings` = `uniwien`, nur Übungen = `constructed`. **Neue SL24-Abschnitte immer mit `"herkunft":"sl24"`** und ans **Ende** der Lektion anhängen; bestehende Abschnitte und Übungen bleiben unberührt. Code: `courseChunkHerkunft()` in `trainer.html`, Knöpfe in `renderCourseOverview` in `neu/neu.js`. Der Beleg `sl24` (🟣) kennzeichnet Material aus dem gekauften Sprachenlernen24-Kurs (nachrangiger Beleg, siehe IMPORTS.md).

### Position-Verschiebung beim nachträglichen Einfügen

`course_exercises.position` ist Integer ohne Unique-Constraint. Beim Einfügen VOR bestehenden Items: `UPDATE ... SET position = position + 1 WHERE course_lesson_id=X AND position >= Y` — ein zu niedriger Y-Wert erwischt mehr Zeilen als beabsichtigt. Nach jedem Positions-Shift die betroffene Chunk-Sequenz per SELECT gegenprüfen.

## Kurs-Verknüpfung: vocab_lesson_refs

Nach jedem Vokabel-Batch (neue INSERTs oder gefundene Duplikate) muss `course_lessons.vocab_lesson_refs` der jeweiligen Lektion aktualisiert werden — mit echten Vokabel-IDs, nicht nur als Text-Liste.

**Pflichtformat (technischer Zwang, kein Stilratschlag):** `vocab_lesson_refs` ist KEIN einfaches Komma-Array. Die App (`parseCourseVocabRefs()` in trainer.html) erwartet exakt `ids:<id1>,<id2>,...|darija:<wort1>,<wort2>,...`. Ein Format ohne diese Präfixe wird komplett ignoriert (`part.split(':')` liefert `length<2`, die Funktion bricht ohne Fehler ab — aber auch ohne verknüpfte Vokabel).

Bei Live-Zugriff einfach mit `RETURNING id, darija` direkt nach dem INSERT arbeiten. Nur ohne Live-Zugriff braucht es die Subquery, die auf (darija, lesson_id)-Paare matcht:

```sql
WITH refs AS (
  SELECT id, darija FROM vocabulary WHERE (darija, lesson_id) IN (('arba3tash',31),('tsa3tash',31))
)
UPDATE course_lessons
SET vocab_lesson_refs = 'ids:' || (SELECT string_agg(id::text, ',') FROM refs)
                       || '|darija:' || (SELECT string_agg(darija, ',') FROM refs)
WHERE course_number = 2;
```

Bei nachträglicher Ergänzung reicht `||','||neue_ids` NICHT — der bestehende String muss geparst (beide Teile getrennt erweitert) und neu zusammengesetzt werden, sonst entsteht wieder ein kaputtes Format.

Im selben Zug immer auch `progress` mitziehen — für `next_review = NULL` fällig setzen (bestehende SRS-Termine nie überschreiben), für neue Vokabeln ohne progress-Zeile eine anlegen:

```sql
WITH refs AS (
  SELECT id FROM vocabulary WHERE (darija, lesson_id) IN (('arba3tash',31),('tsa3tash',31))
)
UPDATE progress
SET next_review = now()
WHERE user_id = '6c6eff77-6b56-4ba9-b445-b1cd47773b41'
  AND vocabulary_id IN (SELECT id FROM refs)
  AND next_review IS NULL;

WITH refs AS (
  SELECT id FROM vocabulary WHERE (darija, lesson_id) IN (('arba3tash',31),('tsa3tash',31))
)
INSERT INTO progress (user_id, vocabulary_id, correct_count, wrong_count, review_count, next_review)
SELECT '6c6eff77-6b56-4ba9-b445-b1cd47773b41', r.id, 0, 0, 0, now()
FROM refs r
WHERE NOT EXISTS (SELECT 1 FROM progress p WHERE p.user_id = '6c6eff77-6b56-4ba9-b445-b1cd47773b41' AND p.vocabulary_id = r.id);
```

Die (darija, lesson_id)-Paare und der `WHERE course_number`-Wert sind nur ein Beispiel — bei jedem neuen Batch durch die tatsächlichen Werte ersetzen.


**Lösungszeile der Regelkarten (seit 2026-11-10):** Für Karten mit `meta.layout = 'regelkarte'` erzeugt der Trainer `solution` beim Laden aus `meta.regelkarte` (`regelLoesungText()`: Antwort/Tabelle/Schritte bzw. Einordnung, dann „Regel: …“, Sicher-Zeile, Beispiele). Pflegen nur noch in `meta`; die Spalte `solution` in Supabase ist für diese Karten nur ein Abbild (Suche, Partner-Ansicht, SQL-Checks) und muss nicht von Hand nachgezogen werden. Der gespeicherte Text steht im Trainer als `e._solDb`.
